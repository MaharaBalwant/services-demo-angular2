import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Item, itemsList } from './component-a.model';
import { MyserviceService } from '../services/myservice.service';

@Component({
  selector: 'app-component-a',
  templateUrl: './component-a.component.html',
  styleUrls: ['./component-a.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ComponentAComponent implements OnInit {

  price:number;
  itemObj:any;
  productArr:any[];
  myserv:MyserviceService;

  constructor(myserv:MyserviceService) { 
    this.itemObj = new Item();
    this.myserv = myserv;
  }

  ngOnInit() {
  }

  searchPoductInput(event){
    this.price = event.target.value;
  }

  searchBtn(){
    this.itemObj.searchItem(this.price);
    this.productArr = this.itemObj.searchItem(this.price); 
    this.myserv.changeProdArr(this.productArr);
  }

  sortBtn(){
    this.myserv.changeProdArr(this.itemObj.sortItem(this.productArr));
  }

}
