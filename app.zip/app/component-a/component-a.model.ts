export class Item{
    
        //constructor(private mevent:any, private mobArr:any[]){ }
    
        searchItem(mobPrice:number):any[]{
            return itemsList.mobileArr.filter( x => x.price >= mobPrice);
        }
    
        sortItem(mobArr:any[]):any{

            mobArr.sort( function(name1, name2) {
                if ( name1.price < name2.price ){
                return -1;
                }else if( name1.price > name2.price ){
                    return 1;
                }else{
                return 0;	
                }
            });
        }
    }
    
    export const itemsList = { 
        mobileArr : [
            {id:1,name:'Nokia',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:7000,desc:'This is desc ..!'},
            {id:2,name:'Samsung',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:6000,desc:'This is desc ..!'},
            {id:3,name:'Lava',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:7500,desc:'This is desc ..!'},
            {id:4,name:'Iphone',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:4000,desc:'This is desc ..!'},
            {id:5,name:'Oppo',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:3000,desc:'This is desc ..!'},
            {id:6,name:'Vivo',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:12000,desc:'This is desc ..!'},
            {id:7,name:'Motorola',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:8000,desc:'This is desc ..!'},
            {id:8,name:'Lenova',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:7000,desc:'This is desc ..!'},
            {id:9,name:'Sony',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:6700,desc:'This is desc ..!'},
            {id:10,name:'Dell',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:1200,desc:'This is desc ..!'},
            {id:11,name:'Nokia',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:7100,desc:'This is desc ..!'},
            {id:12,name:'Acer',image:'https://d3nevzfk7ii3be.cloudfront.net/igi/MqGZWCWTTRYMR5a5.large',price:2100,desc:'This is desc ..!'}
        ]
      }