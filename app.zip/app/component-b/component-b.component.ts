import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { ComponentAComponent } from '../component-a/component-a.component';
import { MyserviceService } from '../services/myservice.service';

@Component({
  selector: 'app-component-b',
  templateUrl: './component-b.component.html',
  styleUrls: ['./component-b.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ComponentBComponent implements OnInit {

  itemObj:any;
  prodArr:any[];
  myserv:MyserviceService;
  arrayAfterSearch:any[];

  @Input()
  sArr:any[];
  constructor(myserv:MyserviceService) {
    this.myserv = myserv;
   }

  ngOnInit() {
    this.prodArr = this.myserv.defaultArr();
  }

  clickCbtn(){
    console.log(this.myserv.getProdArr());
  }
}
