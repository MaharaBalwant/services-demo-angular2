import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { ComponentBComponent } from '../component-b/component-b.component';
import { Item, itemsList } from '../component-a/component-a.model';
import { MyserviceService } from '../services/myservice.service';

@Component({
  selector: 'app-component-c',
  templateUrl: './component-c.component.html',
  styleUrls: ['./component-c.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ComponentCComponent implements OnInit {

  myservice:MyserviceService;

  @Input()
  prodArr:any[];
  constructor(myservice:MyserviceService) { 
    this.myservice = myservice;
  }

  ngOnInit() {
    this.prodArr = this.myservice.defaultArr();
  }

  showServiceValue():void{
    //this.prodArr = this.myservice.getProdArr();
    this.prodArr = this.prodArr;
  }

}
