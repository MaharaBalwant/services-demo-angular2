import { Injectable } from '@angular/core';
import {Item, itemsList } from '../component-a/component-a.model';

@Injectable()
export class MyserviceService {
  prodArr:any[];

  constructor() {
   }

  changeProdArr(prodArr:any[]):void{
    this.prodArr = prodArr;
  }
  
  getProdArr():any[]{
    return this.prodArr;
  }

  defaultArr():any[]{
    return itemsList.mobileArr;
  }

}
